// Smooth scroll for navbar links

document.querySelectorAll("header ul li a").forEach(link => {

  link.addEventListener("click", function(e) {

    e.preventDefault();

    const target = document.querySelector(this.getAttribute("href"));

    target.scrollIntoView({ behavior: "smooth" });

  });

});

// Typing effect for Hero title

const text = "Hello I'm Kataksha";

let i = 0;

function typeEffect() {

  if (i < text.length) {

    document.querySelector(".hero h1").textContent += text.charAt(i);

    i++;

    setTimeout(typeEffect, 100);

  }

}

document.querySelector(".hero h1").textContent = ""; 

typeEffect();

// Button click alert

document.querySelector(".btn")?.addEventListener("click", () => {

  alert("Thanks for checking my work! 🚀");

});
